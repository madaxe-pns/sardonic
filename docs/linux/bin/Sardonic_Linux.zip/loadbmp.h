SDL_Surface *sdl_loadbmp(const char *filename);
SDL_Surface *sdl_display_surface(SDL_Surface *surface);
